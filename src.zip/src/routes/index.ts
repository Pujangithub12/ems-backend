import { Router } from "express";
import { AuthController } from "../controllers/AuthController";
import { UserController } from "../controllers/UserController";
import { AnnouncementController } from "../controllers/AnnouncementController";
import { ProjectController } from "../controllers/ProjectController";
import { TaskController } from "../controllers/TaskController";
import { MyTaskController } from "../controllers/MyTaskController";
import { LeaveRequestController } from "../controllers/LeaveRequestController";
import { CalendarEventController } from "../controllers/CalendarEventController";
import { ActivityController } from "../controllers/ActivityController";
import { WorkspaceController } from "../controllers/WorkspaceController";
import { HierarchyController } from "../controllers/HierarchyController";
import { authMiddleware, roleMiddleware } from "../middlewares/auth";
import { upload } from "../middlewares/upload";
import { UserRole } from "../entities/User";

const router = Router();

// Auth routes
router.post("/login", AuthController.login);
router.post("/logout", AuthController.logout);
router.get("/me", authMiddleware, AuthController.getMe);
router.get("/health", (req, res) => {
  res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
});

// Workspace routes
router.get("/workspaces", authMiddleware, WorkspaceController.getAll);
router.post("/workspaces", authMiddleware, WorkspaceController.create);
router.post("/workspaces/switch", authMiddleware, WorkspaceController.switch);
router.get(
  "/workspaces/current",
  authMiddleware,
  WorkspaceController.getCurrent,
);

// User routes - Admin only for adding and deleting users
router.post(
  "/users",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  UserController.addUser,
);
router.get("/users", authMiddleware, UserController.getAllUsers);
router.delete(
  "/users/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  UserController.deleteUser,
);
router.put(
  "/users/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  UserController.updateUser,
);

// Announcement routes - Admin only for creating and deleting
router.post(
  "/announcements",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  AnnouncementController.createAnnouncement,
);
router.get("/announcements", authMiddleware, AnnouncementController.getHistory);
router.delete(
  "/announcements/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  AnnouncementController.deleteAnnouncement,
);

// Project routes
router.post(
  "/projects",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.createProject,
);
router.get("/projects", authMiddleware, ProjectController.getAllProjects);
router.get("/projects/:id", authMiddleware, ProjectController.getProjectById);
router.put(
  "/projects/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.updateProject,
);
router.delete(
  "/projects/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.deleteProject,
);

// Project task routes
router.post(
  "/projects/:projectId/tasks",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.addProjectTask,
);
router.put(
  "/tasks/:id/progress",
  authMiddleware,
  TaskController.updateTaskProgress,
);

router.put(
  "/tasks/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  upload.array("files"),
  TaskController.updateTask,
);
router.put(
  "/projects/tasks/:taskId",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.updateProjectTask,
);
router.delete(
  "/projects/tasks/:taskId",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.deleteProjectTask,
);
router.get(
  "/projects/:projectId/tasks",
  authMiddleware,
  TaskController.getTasksByProject,
);

// Project heading routes
router.post(
  "/projects/:projectId/headings",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.addProjectHeading,
);

// Project file routes
router.post(
  "/projects/:projectId/files",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.addProjectFile,
);
router.delete(
  "/projects/files/:fileId",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  ProjectController.deleteProjectFile,
);

// Personal task routes
router.post("/mytasks", authMiddleware, MyTaskController.createMyTask);
router.get("/mytasks", authMiddleware, MyTaskController.getMyTasks);
router.put("/mytasks/:id", authMiddleware, MyTaskController.updateMyTask);
router.delete("/mytasks/:id", authMiddleware, MyTaskController.deleteMyTask);

// Task routes
router.post(
  "/tasks",
  authMiddleware,
  // roleMiddleware([UserRole.ADMIN]),
  upload.array("files"),
  TaskController.createTask,
);
router.get("/tasks", authMiddleware, TaskController.getAllTasks);
router.get("/tasks/:id", authMiddleware, TaskController.getTaskById);
router.get("/dashboard", authMiddleware, TaskController.getDashboard);
router.put(
  "/tasks/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  upload.array("files"),
  TaskController.updateTask,
);
router.put(
  "/tasks/:id/status",
  authMiddleware,
  TaskController.updateTaskStatus,
);
router.delete(
  "/tasks/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  TaskController.deleteTask,
);

// Subtask routes

router.get(
  "/tasks/:taskId/subtasks",
  authMiddleware,
  TaskController.getSubTasks,
);

router.post(
  "/tasks/:taskId/subtasks",
  authMiddleware,
  // roleMiddleware([UserRole.ADMIN]),
  TaskController.addSubTask,
);
router.put(
  "/tasks/:taskId/subtasks/:subtaskId",
  authMiddleware,
  // roleMiddleware([UserRole.ADMIN]),
  TaskController.updateSubTask,
);

// Comment routes
router.post(
  "/tasks/:taskId/comments",
  authMiddleware,
  TaskController.addComment,
);
router.get(
  "/tasks/:taskId/comments",
  authMiddleware,
  TaskController.getTaskComments,
);
router.put(
  "/tasks/:taskId/comments/:commentId/feedback",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  TaskController.addFeedback,
);

// Subtask comment routes
router.post(
  "/tasks/:taskId/subtasks/:subtaskId/comments",
  authMiddleware,
  TaskController.addSubTaskComment,
);
router.get(
  "/tasks/:taskId/subtasks/:subtaskId/comments",
  authMiddleware,
  TaskController.getSubTaskComments,
);
router.put(
  "/tasks/:taskId/subtasks/:subtaskId/comments/:commentId/feedback",
  authMiddleware,
  TaskController.addSubTaskFeedback,
);

// Leave request routes
router.post(
  "/leaverequest",
  authMiddleware,
  LeaveRequestController.createLeaveRequest,
);

router.get(
  "/leaverequest",
  authMiddleware,
  LeaveRequestController.getAllLeaveRequests,
);

router.get(
  "/leaverequest/:id",
  authMiddleware,
  LeaveRequestController.getLeaveRequestById,
);

router.put(
  "/leaverequest/:id/status",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  LeaveRequestController.updateStatus,
);

router.put(
  "/leaverequest/:id",
  authMiddleware,
  LeaveRequestController.updateLeaveRequest,
);

router.delete(
  "/leaverequest/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  LeaveRequestController.deleteLeaveRequest,
);

// Calendar Event routes
router.get("/events", authMiddleware, CalendarEventController.getAllEvents);
router.post(
  "/events",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  CalendarEventController.createEvent,
);
router.delete(
  "/events/:id",
  authMiddleware,
  roleMiddleware([UserRole.ADMIN]),
  CalendarEventController.deleteEvent,
);

// Activity routes
router.get("/activities", authMiddleware, ActivityController.getAllActivities);

// Hierarchy routes
router.get("/hierarchy", authMiddleware, HierarchyController.getHierarchy);
router.put("/hierarchy", authMiddleware, HierarchyController.saveHierarchy);

// Date conversion is now handled on the frontend; server routes removed.

export default router;
